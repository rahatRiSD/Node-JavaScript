//jshint esversion:6
const sh=require("superheroes");
console.log(sh.random())

const sv=require("supervillains");
console.log(sv.random())